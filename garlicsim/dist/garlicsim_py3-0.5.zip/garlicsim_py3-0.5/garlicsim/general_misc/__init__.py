# Copyright 2009-2010 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
This package defines a variety of little objects that are completely decoupled
from garlicsim and do not belong anywhere else.
'''