from .life import *
from garlicsim.misc import settings

DETERMINISM_FUNCTION = determinism_function
SCALAR_STATE_FUNCTIONS = [live_cells]
SCALAR_HISTORY_FUNCTIONS = [changes]