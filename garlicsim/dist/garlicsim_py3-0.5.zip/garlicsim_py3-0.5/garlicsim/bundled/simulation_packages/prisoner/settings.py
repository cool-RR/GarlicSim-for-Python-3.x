from garlicsim.misc import settings

SCALAR_STATE_FUNCTIONS = []
SCALAR_HISTORY_FUNCTIONS = []