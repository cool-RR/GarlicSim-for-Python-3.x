# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
This module defines the `PiCloudCruncher` class, which is merely a placeholder.

See its documentation for more information.

The real `PiCloudCruncher` will probably be released in GarlicSim 0.7 in
mid-2011.
'''

from .pi_cloud_cruncher import PiCloudCruncher
