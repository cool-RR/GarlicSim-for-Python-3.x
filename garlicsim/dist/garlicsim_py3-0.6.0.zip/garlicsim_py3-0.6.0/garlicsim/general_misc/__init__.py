# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
This package defines a variety of general tools.

These tools are completely decoupled from the rest of `garlicsim` and have
nothing to do with computer simulations.
'''