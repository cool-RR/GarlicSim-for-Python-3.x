
import garlicsim

# FORCE_CRUNCHER = garlicsim.asynchronous_crunching.crunchers.CruncherThread

SCALAR_STATE_FUNCTIONS = []
SCALAR_HISTORY_FUNCTIONS = []