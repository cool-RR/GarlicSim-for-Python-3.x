# Copyright 2009-2010 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''
Widgets for `prisoner`.
'''

from state_viewer import StateViewer