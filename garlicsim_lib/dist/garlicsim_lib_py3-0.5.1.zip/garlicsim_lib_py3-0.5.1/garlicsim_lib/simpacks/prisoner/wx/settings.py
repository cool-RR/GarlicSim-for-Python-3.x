import widgets

SEEK_BAR_GRAPHS = []
BIG_WORKSPACE_WIDGETS = [widgets.StateViewer]
SMALL_WORKSPACE_WIDGETS = []