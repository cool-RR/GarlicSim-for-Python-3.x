from .life import *

DETERMINISM_FUNCTION = determinism_function
SCALAR_STATE_FUNCTIONS = [State.get_n_live_cells]
SCALAR_HISTORY_FUNCTIONS = [changes]