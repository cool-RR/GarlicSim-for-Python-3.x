# Copyright 2009-2010 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''A package of widgets.'''

from state_viewer import StateViewer