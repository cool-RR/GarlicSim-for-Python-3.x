# Copyright 2009-2010 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

'''Defines widgets to be used for life in garlicsim_wx.'''

from board_viewer import BoardViewer