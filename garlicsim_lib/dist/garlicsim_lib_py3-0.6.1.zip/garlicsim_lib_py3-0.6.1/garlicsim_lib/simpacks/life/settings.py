# Copyright 2009-2011 Ram Rachum.
# This program is distributed under the LGPL2.1 license.

from .state import determinism_function, State

DETERMINISM_FUNCTION = determinism_function

#SCALAR_STATE_FUNCTIONS = [State.get_n_live_cells]
#SCALAR_HISTORY_FUNCTIONS = [changes]
