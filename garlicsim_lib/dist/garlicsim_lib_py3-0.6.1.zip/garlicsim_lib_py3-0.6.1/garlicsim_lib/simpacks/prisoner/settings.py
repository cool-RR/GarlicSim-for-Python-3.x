
import garlicsim

# CRUNCHERS = garlicsim.asynchronous_crunching.crunchers.ThreadCruncher

SCALAR_STATE_FUNCTIONS = []
SCALAR_HISTORY_FUNCTIONS = []